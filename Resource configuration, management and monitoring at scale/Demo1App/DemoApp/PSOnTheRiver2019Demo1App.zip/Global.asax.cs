﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Optimization;

using Amazon.EC2;
using Amazon.EC2.Model;
using AWS.Logger.Log4net;
using log4net;
using log4net.Core;
using log4net.Layout;
using log4net.Repository.Hierarchy;

namespace PSOnTheRiver2019Demo1App
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private static ILog LOGGER = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(System.Web.Routing.RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            ConfigureLog4Net();

            LOGGER.InfoFormat("Application started");
        }

        static void ConfigureLog4Net()
        {
            // perform configuration from code instead of static config file
            // so we can use the instance's Name tag value to find the
            // correct log group for this application. An alternative way to do
            // this would be to fetch the data from a known-in-advance Parameter 
            // Store key.
            string logGroupName = null;

            try
            {
                var instanceId = Amazon.Util.EC2InstanceMetadata.InstanceId;
                var ec2Client = new AmazonEC2Client();
                // using a single, unpaginated call, on the assumption we're not applying
                // a lot of tags to these demo instances!
                var tagsResponse = ec2Client.DescribeTags(new DescribeTagsRequest
                {
                    Filters = new List<Amazon.EC2.Model.Filter>
                    {
                        new Amazon.EC2.Model.Filter
                        {
                            Name = "resource-id",
                            Values = new List<string>
                            {
                                instanceId
                            }
                        },
                        new Amazon.EC2.Model.Filter
                        {
                            Name = "resource-type",
                            Values = new List<string>
                            {
                                "instance"
                            }
                        }
                    }
                });

                foreach (var tag in tagsResponse.Tags)
                {
                    if (string.Equals(tag.Key, "Name", System.StringComparison.OrdinalIgnoreCase))
                    {
                        logGroupName = tag.Value;
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.Fail("Unable to read instance name tag to set log group", e.Message);
                logGroupName = System.Environment.MachineName;
            }

            var hierarchy = (Hierarchy)LogManager.GetRepository();
            var patternLayout = new PatternLayout
            {
                ConversionPattern = "%-4timestamp [%thread] %-5level %logger %ndc - %message%newline"
            };
            patternLayout.ActivateOptions();

            var appender = new AWSAppender
            {
                Layout = patternLayout,
                LogGroup = $"{logGroupName}"
            };

            appender.ActivateOptions();
            hierarchy.Root.AddAppender(appender);

            hierarchy.Root.Level = Level.All;
            hierarchy.Configured = true;
        }
    }
}
