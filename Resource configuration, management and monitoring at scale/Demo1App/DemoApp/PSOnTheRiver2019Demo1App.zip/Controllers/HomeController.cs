﻿using log4net;
using System;
using System.Web.Mvc;

namespace PSOnTheRiver2019Demo1App.Controllers
{
    public class HomeController : Controller
    {
        private static ILog LOGGER = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public ActionResult Index()
        {
            LOGGER.InfoFormat("/GET request on Index");

            return View();
        }

        public ActionResult CryForHelp()
        {
            var rnd = new Random();

            string[] helpMessages =
            {
                "HELP ME! I've fallen over and can't get up",
                "Sorry, false alarm, embarrassing",
                "HELP ME! I've fallen again",
                "Sorry, another false alarm",
                "Really, I won't cry wolf again, please HELP ME! I broked :-("
            };

            var index = rnd.Next(helpMessages.Length);

            LOGGER.InfoFormat(helpMessages[index]);

            return RedirectToAction("Index");
        }
    }
}